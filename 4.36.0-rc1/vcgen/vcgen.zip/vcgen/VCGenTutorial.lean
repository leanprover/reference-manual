import Std.Data.HashMap
import Std.Data.HashSet

import Std.WP
import Std.Tactic.Do

set_option experimental.vcgen true

namespace VCGenTutorial

section

open Std.WP Lean.Order

def mySum (l : Array Nat) : Nat := Id.run do
  let mut out := 0
  for i in l do
    out := out + i
  return out

theorem mySum_correct (l : Array Nat) : mySum l = l.sum := by
  -- Focus on the part of the program with the `do` block (`Id.run ...`)
  generalize h : mySum l = x
  apply Id.of_run_eq_wp h
  -- Break down into verification conditions
  vcgen
  -- Specify the invariant which should hold throughout the loop.
  -- It is a function of three arguments:
  -- * `pref` is the list of elements that the loop has already visited
  -- * `suff` is the list of elements that the loop has yet to visit
  -- * `out` is the current value of the `let mut` variable
  -- Our invariant is that `out` holds the sum of the prefix.
  case inv1 => exact fun pref suff out => pref.sum = out
  -- Prove that the invariant is true at the start
  case vc1 =>
    grind
  -- Prove that the invariant at the end of the loop implies the
  -- property we wanted
  case vc2 =>
    grind
  -- Prove that our invariant is preserved at each step of the loop
  case vc3 =>
    grind

theorem mySum_correct_short (l : Array Nat) : mySum l = l.sum := by
  generalize h : mySum l = x
  apply Id.of_run_eq_wp h
  vcgen
  case inv1 => exact fun pref suff out => pref.sum = out
  all_goals grind

theorem mySum_correct_shorter (l : Array Nat) : mySum l = l.sum := by
  generalize h : mySum l = x
  apply Id.of_run_eq_wp h
  vcgen invariants
  · fun pref suff out => pref.sum = out
  with finish

theorem mySum_correct_vanilla (l : Array Nat) : mySum l = l.sum := by
  -- Turn the array into a list
  cases l with | mk l =>
  -- Unfold `mySum` and rewrite `forIn` to `foldl`
  simp [mySum]
  -- Generalize the inductive hypothesis
  suffices h : ∀ out, List.foldl (· + ·) out l = out + l.sum by simp [h]
  -- Grind away
  induction l with grind

def nodup (l : List Int) : Bool := Id.run do
  let mut seen : Std.HashSet Int := ∅
  for x in l do
    if x ∈ seen then
      return false
    seen := seen.insert x
  return true

-- A future 4.36 release adds these annotations to the library.
attribute [local grind norm]
  Lean.Order.ofProp_prop_eq Lean.Order.meet_prop_eq_and
  Lean.Order.join_prop_eq_or Lean.Order.iSup_prop_eq_exists

theorem nodup_correct (l : List Int) : nodup l ↔ l.Nodup := by
  generalize h : nodup l = r
  apply Id.of_run_eq_wp h
  vcgen invariants
  · Invariant.withEarlyReturnNewDo
      (onReturn := fun ret seen => ret = false ∧ ¬l.Nodup)
      (onContinue := fun pref suff seen =>
        (∀ x, x ∈ seen ↔ x ∈ pref) ∧ pref.Nodup)
  with finish

theorem nodup_correct_directly (l : List Int) : nodup l ↔ l.Nodup := by
  rw [nodup]
  generalize hseen : (∅ : Std.HashSet Int) = seen
  change ?lhs ↔ l.Nodup
  suffices h : ?lhs ↔ l.Nodup ∧ ∀ x ∈ l, x ∉ seen by grind
  clear hseen
  induction l generalizing seen with grind [Id.run_pure, Id.run_bind]

structure Supply where
  counter : Nat

def mkFresh : StateM Supply Nat := do
  let n ← (·.counter) <$> get
  modify fun s => { s with counter := s.counter + 1 }
  pure n

def mkFreshN (n : Nat) : StateM Supply (List Nat) := do
  let mut acc := #[]
  for _ in [:n] do
    acc := acc.push (← mkFresh)
  pure acc.toList

theorem mkFreshN_correct (n : Nat) : ((mkFreshN n).run' s).Nodup := by
  -- Focus on `(mkFreshN n).run' s`.
  generalize h : (mkFreshN n).run' s = x
  apply StateM.of_run'_eq_wp h
  -- Show something about monadic program `mkFresh n`.
  -- The `mkFreshN` and `mkFresh` arguments make `vcgen` unfold
  -- these definitions.
  vcgen [mkFreshN, mkFresh] invariants
  -- Invariant: The counter is larger than any accumulated number,
  --            and all accumulated numbers are distinct.
  -- Note that the invariant may refer to the state through function
  -- argument `state : Supply`. Since the next number to accumulate is
  -- the counter, it is distinct to all accumulated numbers.
  · fun pref suff acc state =>
      (∀ x ∈ acc, x < state.counter) ∧ acc.toList.Nodup
  with finish

def StateMTriple {α σ : Type} (prog : StateM σ α)
    (P : σ → Prop) (Q : α → σ → Prop) : Prop :=
  ∀ s, P s → let (a, s') := prog.run s; Q a s'

@[spec]
theorem mkFresh_spec (c : Nat) :
    ⦃fun state => state.counter = c⦄
    mkFresh
    ⦃fun r state => r = c ∧ c < state.counter⦄ := by
  -- Unfold `mkFresh` and blast away:
  vcgen [mkFresh] with finish

@[spec]
theorem mkFreshN_spec (n : Nat) :
    ⦃fun _ => True⦄ mkFreshN n ⦃fun r _ => r.Nodup⦄ := by
  -- `vcgen [mkFreshN, mkFresh_spec]` if `mkFresh_spec` were not
  -- registered with `@[spec]`
  vcgen [mkFreshN] invariants
  -- As before:
  · fun pref suff acc state =>
      (∀ x ∈ acc, x < state.counter) ∧ acc.toList.Nodup
  with finish

theorem mkFreshN_correct_modular (n : Nat) :
    ((mkFreshN n).run' s).Nodup := by
  generalize h : (mkFreshN n).run' s = x
  apply StateM.of_run'_eq_wp h
  vcgen

namespace Transformers

abbrev CounterM := StateT Supply (ReaderM String)

abbrev AppM := StateT Bool CounterM

def mkFresh : CounterM Nat := do
  let n ← (·.counter) <$> get
  modify fun s => { s with counter := s.counter + 1 }
  pure n

def mkFreshN (n : Nat) : AppM (List Nat) := do
  let mut acc := #[]
  for _ in [:n] do
    let n ← mkFresh
    acc := acc.push n
  return acc.toList

@[spec]
theorem mkFresh_spec (c : Nat) :
    ⦃fun state => ⌜state.counter = c⌝⦄
    mkFresh
    ⦃fun r state => ⌜r = c ∧ c < state.counter⌝⦄ := by
  vcgen [mkFresh] with finish

@[spec]
theorem mkFreshN_spec (n : Nat) :
    ⦃⌜True⌝⦄ mkFreshN n ⦃fun r => ⌜r.Nodup⌝⦄ := by
  vcgen [mkFreshN] invariants
  · fun pref suff acc _ state =>
      ⌜(∀ n ∈ acc, n < state.counter) ∧ acc.toList.Nodup⌝
  with finish

end Transformers

namespace Exceptions

structure Supply where
  counter : Nat
  limit : Nat
  property : counter ≤ limit

def mkFresh : EStateM String Supply Nat := do
  let supply ← get
  if h : supply.counter = supply.limit then
    throw s!"Supply exhausted: {supply.counter} = {supply.limit}"
  else
    let n := supply.counter
    have := supply.property
    set { supply with counter := n + 1, property := by grind }
    pure n

@[spec]
theorem mkFresh_spec (c : Nat) :
    ⦃fun state => state.counter = c⦄
    mkFresh
    ⦃fun r state => r = c ∧ c < state.counter;
      fun _ state => c = state.counter ∧ c = state.limit⦄ := by
  vcgen [mkFresh] with finish

def mkFreshN (n : Nat) : EStateM String Supply (List Nat) := do
  let mut acc := #[]
  for _ in [:n] do
    acc := acc.push (← mkFresh)
  pure acc.toList

@[spec]
theorem mkFreshN_spec (n : Nat) :
    ⦃fun _ => True⦄
    mkFreshN n
    ⦃fun r _ => r.Nodup;
      fun _msg state => state.counter = state.limit⦄ := by
  vcgen [mkFreshN] invariants
  · fun pref suff acc state =>
      (∀ n ∈ acc, n < state.counter) ∧ acc.toList.Nodup
  with finish

theorem mkFreshN_correct (n : Nat) :
    match (mkFreshN n).run s with
    | .ok    l _  => l.Nodup
    | .error _ s' => s'.counter = s'.limit := by
  generalize h : (mkFreshN n).run s = x
  apply EStateM.of_run_eq_wp h
  vcgen with finish

end Exceptions

inductive Error where
  | integerOverflow: Error
  -- ... more error kinds ...

inductive Result (α : Type u) where
  | ok (v: α): Result α
  | fail (e: Error): Result α
  | div

instance Result.instMonad : Monad Result where
  pure x := .ok x
  bind x f := match x with
  | .ok v => f v
  | .fail e => .fail e
  | .div => .div

instance Result.instLawfulMonad : LawfulMonad Result := by
  apply LawfulMonad.mk' _
  all_goals (dsimp [Functor.map, bind, pure]; grind)

instance : WP (Result α) α Prop (Error → Prop) where
  trans
    | .ok v => ⟨fun post _ => post v⟩
    | .fail e => ⟨fun _ epost => epost e⟩
    | .div => ⟨fun _ _ => False⟩
  trans_monotone x := by
    intro post post' epost epost' hepost hpost
    cases x <;> simp_all [PartialOrder.rel]

instance Result.instWPMonad : WPMonad Result Prop (Error → Prop) where
  toWP _ := inferInstance
  pure_le_wp_pure x post epost := PartialOrder.rel_refl
  bind_le_wp_bind x f post epost := by
    cases x <;> simp [wp, WP.trans, bind, PartialOrder.rel]

theorem Result.of_eq_wp {α} {x prog : Result α}
    (h : prog = x) (P : Result α → Prop)
    (hwp : wp prog (fun a => P (.ok a)) (fun e => P (.fail e))) :
      P x := by
  subst h
  match prog with
  | .ok a   => simpa [wp, WP.trans] using hwp
  | .fail e => simpa [wp, WP.trans] using hwp
  | .div    => simp [wp, WP.trans] at hwp

instance : MonadExcept Error Result where
  throw e := .fail e
  tryCatch x h := match x with
  | .ok v => pure v
  | .fail e => h e
  | .div => .div

def addOp (x y : UInt32) : Result UInt32 :=
  if x.toNat + y.toNat ≥ UInt32.size then
    throw .integerOverflow
  else
    pure (x + y)

@[spec]
theorem Result.throw_spec {α} {post : α → Prop}
    {epost : Error → Prop} (e : Error) :
    ⦃epost e⦄ throw (m := Result) (α := α) e ⦃post; epost⦄ :=
  ⟨PartialOrder.rel_refl⟩

@[spec]
theorem addOp_ok_spec {x y} (h : x.toNat + y.toNat < UInt32.size) :
    ⦃True⦄
    addOp x y
    ⦃fun r => r = x + y ∧ (x + y).toNat = x.toNat + y.toNat⦄ := by
  vcgen [addOp]
  all_goals simp_all; try grind

example :
  ⦃True⦄
  (do let mut x ← addOp 1 3
      for _ in [:4] do
        x ← addOp x 5
      return x : Result UInt32)
  ⦃fun r => r.toNat = 24⦄ := by
  vcgen invariants
  · fun pref suff x => x.toNat = 4 + 5 * pref.length
  all_goals simp_all
  all_goals grind

end

end VCGenTutorial
